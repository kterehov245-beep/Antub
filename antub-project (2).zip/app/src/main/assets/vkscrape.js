(function(){
 var seen={},out=[];
 function num(s){return parseFloat(String(s).replace(/[\s\u00a0]/g,'').replace(',','.'))||0}
 function ks(b){var o={},l=b.querySelectorAll('a[href]');for(var i=0;i<l.length;i++){var m=l[i].getAttribute('href').match(/video(-?\d+_\d+)/);if(m)o[m[1]]=1}return Object.keys(o)}
 function bgOf(b){var e=b.querySelectorAll('*'),n=Math.min(e.length,60);for(var i=0;i<n;i++){var u=(e[i].style&&e[i].style.backgroundImage||'').match(/url\(["']?([^"')]+)/);if(u)return u[1]}return ''}
 var as=document.querySelectorAll('a[href]');
 for(var i=0;i<as.length;i++){
  var m=as[i].getAttribute('href').match(/video(-?\d+)_(\d+)/);if(!m)continue;
  var key=m[1]+'_'+m[2];if(seen[key])continue;
  var box=as[i],th='';
  for(var u=0;u<7&&box;u++,box=box.parentElement){
   var im=box.querySelector('img');
   th=im?(im.currentSrc||im.src||im.getAttribute('data-src')||''):bgOf(box);
   if(th.indexOf('data:')===0)th='';
   if(th)break;
  }
  if(!box||!th)continue;
  for(var c=0;c<4&&box.parentElement;c++){
   var t0=box.innerText||'';
   if(t0.split('\n').some(function(x){return x.trim().length>=10&&!/просмотр|^\d+:\d\d/.test(x)}))break;
   var p=box.parentElement;if(ks(p).length!==1)break;box=p;
  }
  var txt=box.innerText||'';
  var lines=txt.split('\n').map(function(x){return x.trim()}).filter(Boolean);
  var du=txt.match(/(?:(\d{1,2}):)?(\d{1,2}):(\d{2})/),d=0;
  if(du)d=(+du[1]||0)*3600+(+du[2])*60+(+du[3]);
  var vw=txt.match(/([\d\s\u00a0.,]+?)\s*(тыс|млн)?\.?\s*просмотр/i),v=0;
  if(vw){var mu=(vw[2]||'').toLowerCase();v=num(vw[1])*(mu==='тыс'?1e3:mu==='млн'?1e6:1)}
  var ti='',al=box.querySelectorAll('a[href]');
  for(var k=0;k<al.length&&!ti;k++){if((al[k].getAttribute('href')||'').indexOf(key)>-1){ti=al[k].getAttribute('title')||al[k].getAttribute('aria-label')||''}}
  if(!ti){
   var c2=lines.filter(function(x){return !/^\d{1,2}(:\d{2}){1,2}$/.test(x)&&!/просмотр|назад|вчера|сегодня/i.test(x)&&!/^[\d\s.,]+$/.test(x)}).sort(function(a,b){return b.length-a.length});
   ti=c2[0]||'';
  }
  if(!ti)continue;
  seen[key]=1;out.push({id:key,t:ti,th:th,d:d,v:Math.round(v),oid:m[1],vid:m[2]});
 }
 return out;
})()
